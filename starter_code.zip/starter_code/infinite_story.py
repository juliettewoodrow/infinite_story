import json
from notopenai import NotOpenAI
import os
from graphics import Canvas

# follow the instructions in the notopenai handout to get your free api key
CLIENT = NotOpenAI(api_key="your_api_key_here")
STORY_NAME = "original_small"

def main():
    print("Infinite Story")
    # TODO: your code here



if __name__ == "__main__":
    main()
