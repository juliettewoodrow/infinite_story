import json

STORY_NAME = "original_small"

def main():
    print("Warmup.py")
    # TODO: your code here
    


if __name__ == "__main__":
    main()
