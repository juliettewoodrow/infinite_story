# Not Open Ai Server
-----

If you want to build your own server to host the student not open ai keys you can. But! You don't have to. We have a server running on 
`https://us-central1-notopenai-31af6.cloudfunctions.net`
that we will keep up until at least 2030. You can use the `teacher_code.zip` scripts to create keys for your class.

However, if you want to do it yourself, read on.

## Firebase Functions

The easiest thing to do is to go to 
https://console.firebase.google.com/u/0/

1. Create a project
2. Enable functions
3. Set up the firebase comand line
4. Deploy the functions from this folder



