import { initializeApp } from "firebase-admin/app";

initializeApp();

export * from "./notopenai";

export * from "./generatekeys"