import json
from openai import OpenAI
from pprint import pprint
import requests
import os
from io import BytesIO
from PIL import Image, ImageTk



client = OpenAI(api_key="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")

def main():
    story_data = json.load(open('../soln/data/original_big.json'))
    
    history = []
    recursively_generate_images(story_data, history, 'start', None)

visited = set()

def recursively_generate_images(story_data, history, scene_key, prev_scene):
    if not scene_key in story_data:
        return
    
    if scene_key in visited:
        return
    
    visited.add(scene_key)
    print('Generating image for', scene_key)
    
    scene_data = story_data[scene_key]
    scene_description = get_scene_description(scene_data)
    

    scene_prompt = f"Current scene to illustrate: {scene_description}"
    
    if prev_scene:
        prev_text = story_data[prev_scene]["text"]
        scene_prompt += f"Previous scene: {prev_text}"
    if len(history) > 1:
        last_action = history[-1]
        scene_prompt += f"Last action: {last_action}"

    history.append(f"Current scene: {scene_data['scene_summary']}")

    generate_img(scene_prompt, scene_key)

    for choice in scene_data['choices']:
        history.append(f"Hero: {choice['text']}")
        recursively_generate_images(story_data, history, choice['scene_key'], scene_key)
        history.pop()
    


    # for scene_key in story_data:
    #     scene_data = story_data[scene_key]
    #     scene_description = get_scene_description(scene_data)
        
    #     generate_img(scene_description, prev_scene, scene_key)
    #     prev_scene = scene_data['text']
    #     print(f"Generated image for {scene_key}")


def get_scene_description(scene_data):
    text = scene_data['text']
    choices = ''
    for idx, choice in enumerate(scene_data['choices']):
        choices += f"{idx+1}. {choice['text']}\n"

    return f"Scene: {text}\n. Hero's choices: \n{choices}"

    

def generate_img(scene_description, scene_key):
    path = f"../soln/img/original_big/{scene_key}.png"
    if os.path.exists(path):
        return path

    prompt = f"Craft a vivid and engaging illustration for an immersive game in the style of an award winning Digital Painting, designed to capture the imagination and awe of its audience, bringing to life a world that players can lose themselves in. The art style should evoke a sense of wonder, blending elements of fantasy and realism to create a visually stunning experience. Colors should be rich and vibrant, with lighting that enhances the mood and depth of the scene. Critically important: NEVER ADD TEXT TO THE ILLUSTRATION. Render this scene: {scene_description}"

    response = client.images.generate(
      model="dall-e-3",
      prompt=prompt,
      size="1024x1024",
      quality="standard",
      n=1,
    )

    # get the url
    image_url = response.data[0].url

    response = requests.get(image_url)
    image = Image.open(BytesIO(response.content))
    image.save(path)
    return path


if __name__ == "__main__":
    main()
    