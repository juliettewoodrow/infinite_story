from PIL import Image
import os
from tqdm import tqdm

def reduce_image_size(image_path, new_width, new_height, output_path):
    """Reduces the size of an image, removes the alpha channel if present, and saves it to a new file.

    Args:
        image_path: The path to the input image file.
        new_width: The new width of the image in pixels.
        new_height: The new height of the image in pixels.
        output_path: The path to the output image file.
    """

    image = Image.open(image_path)
    image = image.resize((new_width, new_height))

    # Check if the image has an alpha channel and convert it to RGB if it does
    if image.mode == 'RGBA':
        image = image.convert('RGB')

    image.save(output_path, "JPEG")

if __name__ == "__main__":
    for file_name in tqdm(os.listdir("../infinitestory/img_old")):
        # make sure it ends in .png
        if not file_name.endswith(".png"):
            continue
        image_path = f"../infinitestory/img_old/{file_name}"
        output_file = file_name.replace(".png", ".jpg")
        output_path = f"../infinitestory/img/{output_file}"
        new_width = 600
        new_height = 600
        reduce_image_size(image_path, new_width, new_height, output_path)